-- Run this ONCE in Supabase SQL Editor.
-- This function makes wallet crediting atomic and prevents
-- duplicate M-PESA callbacks from adding money twice.

create or replace function public.credit_wallet(p_transaction_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  tx public.transactions%rowtype;
  new_balance numeric;
begin
  select *
  into tx
  from public.transactions
  where id = p_transaction_id
  for update;

  if not found then
    raise exception 'Transaction not found';
  end if;

  if tx.status = 'completed' then
    return jsonb_build_object(
      'success', true,
      'already_completed', true
    );
  end if;

  if tx.status <> 'pending' then
    raise exception 'Transaction is not pending';
  end if;

  perform 1
  from public.wallets
  where user_id = tx.user_id
  for update;

  if not exists (
    select 1
    from public.wallets
    where user_id = tx.user_id
  ) then
    insert into public.wallets (
      user_id,
      balance,
      currency
    )
    values (
      tx.user_id,
      tx.amount,
      'KES'
    );

    new_balance := tx.amount;
  else
    update public.wallets
    set
      balance = balance + tx.amount,
      updated_at = now()
    where user_id = tx.user_id
    returning balance into new_balance;
  end if;

  update public.transactions
  set
    status = 'completed',
    updated_at = now()
  where id = tx.id
    and status = 'pending';

  return jsonb_build_object(
    'success', true,
    'transaction_id', tx.id,
    'new_balance', new_balance
  );
end;
$$;
